import logging
import requests
from moviepy.editor import VideoFileClip
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters
import os
import uuid

BOT_TOKEN = os.getenv("BOT_TOKEN")

logging.basicConfig(level=logging.INFO)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("👋 Привет! Кинь ссылку на гифку, и я верну тебе Telegram-гид.")

async def handle_link(update: Update, context: ContextTypes.DEFAULT_TYPE):
    url = update.message.text.strip()
    await update.message.reply_text("⏳ Загружаю и обрабатываю гифку...")

    try:
        uid = str(uuid.uuid4())
        gif_path = f"{uid}.gif"
        mp4_path = f"{uid}.mp4"

        # Скачиваем гифку
        response = requests.get(url, timeout=15)
        if response.status_code != 200:
            raise Exception("Не удалось скачать гифку. Убедись, что ссылка рабочая.")
        with open(gif_path, "wb") as f:
            f.write(response.content)

        # Конвертация в mp4 (Telegram-friendly gif)
        clip = VideoFileClip(gif_path)
        clip.write_videofile(mp4_path, codec="libx264", audio=False, fps=15, verbose=False, logger=None)

        # Отправка
        with open(mp4_path, "rb") as f:
            await update.message.reply_animation(f, caption="🎉 Готово!")

    except Exception as e:
        await update.message.reply_text(f"⚠️ Ошибка: {e}")
    finally:
        for file in [gif_path, mp4_path]:
            if os.path.exists(file):
                os.remove(file)

app = ApplicationBuilder().token(BOT_TOKEN).build()

app.add_handler(CommandHandler("start", start))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_link))

app.run_polling()
