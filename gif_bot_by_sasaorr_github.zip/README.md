# gif_bot_by_sasaorr

Telegram-бот, который принимает ссылку на гифку и отправляет её обратно в формате, пригодном для сохранения в Telegram.

## 🚀 Как запустить

1. Клонируй репозиторий
2. Установи зависимости:
   ```
   pip install -r requirements.txt
   ```
3. Запусти:
   ```
   BOT_TOKEN=твой_токен python bot.py
   ```

## 🌐 Railway/Heroku

Для деплоя на Railway:
- Добавь переменную окружения `BOT_TOKEN`
- Запусти команду из Procfile
